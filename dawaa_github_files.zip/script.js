const STORAGE_KEY = "dawaa_app_v1";
const $ = (id) => document.getElementById(id);
let appData = loadData();
let reminderTimer = null;
let lastReminderMinute = "";

function defaultData() {
  return {
    patientName: "", loginEmail: "", beneficiaryPhone: "", emergencyPhone: "",
    reportEmail: "", medicines: [], takenLog: {}
  };
}
function loadData() {
  try { return { ...defaultData(), ...JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}") }; }
  catch { return defaultData(); }
}
function saveData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(appData));
}
function showToast(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 3200);
}
function showScreen(id) {
  document.querySelectorAll(".screen").forEach(s => s.classList.toggle("active", s.id === id));
  document.querySelectorAll(".step").forEach(s => s.classList.remove("active"));
  const index = ({ welcome: 1, settings: 2, medicines: 3 })[id] || 1;
  $("step" + index).classList.add("active");
  window.scrollTo({ top: 0, behavior: "smooth" });
}
function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[c]);
}
function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
function isTaken(medicineId) {
  return appData.takenLog[`${todayKey()}_${medicineId}`] === true;
}
function renderMedicines() {
  const list = $("medicineList");
  $("medicineCount").textContent = appData.medicines.length;
  $("greeting").textContent = `أهلًا ${appData.patientName || ""}، أضف الأدوية ومواعيدها لتسهيل المتابعة اليومية.`;
  if (!appData.medicines.length) {
    list.innerHTML = '<div class="empty-state">لم تتم إضافة أدوية بعد. ابدأ بإضافة أول دواء.</div>';
    return;
  }
  list.innerHTML = appData.medicines
    .slice().sort((a,b) => a.time.localeCompare(b.time))
    .map(m => {
      const taken = isTaken(m.id);
      return `<article class="medicine-item">
        <div class="medicine-top">
          <div><p class="medicine-name">${escapeHtml(m.name)}</p>
          <p class="medicine-dose">${escapeHtml(m.dose)}</p>
          <p class="medicine-time">◷ ${escapeHtml(m.time)}</p></div>
          <span class="${taken ? "taken-badge" : "pending-badge"}">${taken ? "تم تسجيل الجرعة" : "بانتظار الجرعة"}</span>
        </div>
        <div class="medicine-actions">
          <button class="${taken ? "secondary" : "primary"}" onclick="toggleTaken('${m.id}')">${taken ? "إلغاء تسجيل الجرعة" : "✓ تم أخذ الدواء"}</button>
          <button class="secondary" onclick="deleteMedicine('${m.id}')">حذف</button>
        </div>
      </article>`;
    }).join("");
}
function toggleTaken(id) {
  const key = `${todayKey()}_${id}`;
  appData.takenLog[key] = !appData.takenLog[key];
  saveData(); renderMedicines();
  showToast(appData.takenLog[key] ? "تم تسجيل الجرعة لهذا اليوم." : "تم إلغاء تسجيل الجرعة.");
}
function deleteMedicine(id) {
  const item = appData.medicines.find(m => m.id === id);
  if (!item || !confirm(`هل تريد حذف دواء «${item.name}»؟`)) return;
  appData.medicines = appData.medicines.filter(m => m.id !== id);
  saveData(); renderMedicines(); showToast("تم حذف الدواء.");
}
$("loginForm").addEventListener("submit", e => {
  e.preventDefault();
  appData.patientName = $("patientName").value.trim();
  appData.loginEmail = $("loginEmail").value.trim();
  saveData();
  fillSettings();
  showScreen("settings");
});
function fillSettings() {
  $("savedPatientName").value = appData.patientName || "";
  $("beneficiaryPhone").value = appData.beneficiaryPhone || "";
  $("emergencyPhone").value = appData.emergencyPhone || "";
  $("reportEmail").value = appData.reportEmail || appData.loginEmail || "";
}
$("settingsForm").addEventListener("submit", e => {
  e.preventDefault();
  appData.patientName = $("savedPatientName").value.trim();
  appData.beneficiaryPhone = $("beneficiaryPhone").value.trim();
  appData.emergencyPhone = $("emergencyPhone").value.trim();
  appData.reportEmail = $("reportEmail").value.trim();
  saveData(); renderMedicines(); showScreen("medicines");
  showToast("تم حفظ بيانات التواصل على هذا الجهاز.");
});
$("medicineForm").addEventListener("submit", e => {
  e.preventDefault();
  const name = $("medicineName").value.trim();
  const dose = $("medicineDose").value.trim();
  const time = $("medicineTime").value;
  if (!name || !dose || !time) return;
  appData.medicines.push({ id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random())), name, dose, time });
  saveData(); renderMedicines(); e.target.reset();
  showToast("تمت إضافة الدواء إلى الجدول.");
});
$("callButton").addEventListener("click", () => {
  const phone = appData.emergencyPhone.replace(/[^\d+*#]/g, "");
  if (!phone) return showToast("أضف رقم الطوارئ من بيانات التواصل أولًا.");
  if (confirm(`سيتم فتح تطبيق الاتصال للرقم: ${appData.emergencyPhone}\nاضغط اتصال من جهازك لإتمام المكالمة.`)) {
    window.location.href = `tel:${phone}`;
  }
});
$("reportButton").addEventListener("click", () => {
  if (!appData.reportEmail) return showToast("أضف بريد التقرير من بيانات التواصل أولًا.");
  const date = new Date().toLocaleDateString("ar-SA");
  const lines = appData.medicines.map(m => `- ${m.name} (${m.dose})، الوقت ${m.time}: ${isTaken(m.id) ? "تم أخذ الجرعة" : "لم تُسجل الجرعة"}`);
  const body = `التقرير اليومي لتطبيق دوائي\nالتاريخ: ${date}\nالمستفيد: ${appData.patientName}\n\n${lines.length ? lines.join("\n") : "لا توجد أدوية مسجلة."}\n\nملاحظة: حالة الجرعة تعكس ما تم تسجيله في التطبيق فقط.`;
  window.location.href = `mailto:${encodeURIComponent(appData.reportEmail)}?subject=${encodeURIComponent("التقرير اليومي - دوائي")}&body=${encodeURIComponent(body)}`;
});
$("notificationButton").addEventListener("click", async () => {
  if (!("Notification" in window)) return showToast("المتصفح لا يدعم إشعارات الويب.");
  if (!window.isSecureContext) return showToast("افتح الموقع عبر HTTPS (مثل GitHub Pages) لتفعيل الإشعارات.");
  const permission = await Notification.requestPermission();
  if (permission === "granted") {
    new Notification("دوائي", { body: "تم تفعيل إشعارات المتصفح. اترك الصفحة مفتوحة لمتابعة المواعيد." });
    showToast("تم تفعيل الإشعارات لهذا المتصفح.");
  } else showToast("لم يتم السماح بالإشعارات من المتصفح.");
});
function checkReminders() {
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  const now = new Date();
  const minute = `${todayKey()}_${String(now.getHours()).padStart(2,"0")}:${String(now.getMinutes()).padStart(2,"0")}`;
  if (minute === lastReminderMinute) return;
  const due = appData.medicines.filter(m => m.time === minute && !isTaken(m.id));
  if (!due.length) return;
  lastReminderMinute = minute;
  due.forEach(m => {
    const n = new Notification(`موعد الدواء: ${m.name}`, {
      body: `${m.dose} — افتح تطبيق دوائي وسجّل الجرعة بعد أخذها.`,
      tag: `dawaa-${m.id}-${todayKey()}`
    });
    n.onclick = () => { window.focus(); showScreen("medicines"); };
  });
}
function init() {
  $("year").textContent = new Date().getFullYear();
  if (appData.patientName) {
    $("patientName").value = appData.patientName;
    $("loginEmail").value = appData.loginEmail;
    fillSettings();
    renderMedicines();
    showScreen("medicines");
  } else {
    renderMedicines();
    showScreen("welcome");
  }
  // تذكير المتصفح يعمل فقط أثناء بقاء الصفحة مفتوحة.
  reminderTimer = setInterval(checkReminders, 15000);
}
window.showScreen = showScreen;
window.toggleTaken = toggleTaken;
window.deleteMedicine = deleteMedicine;
init();
